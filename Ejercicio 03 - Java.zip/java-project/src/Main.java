import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();

        // Variable para acumular la suma de impares (comienza en 0)
        int sumaImpares = 0;

        // El proceso continúa MIENTRAS la suma sea menor o igual a 25
        while (sumaImpares <= 25) {

            // Generar un número al azar entre 0 y 10
            int numero = random.nextInt(11);

            // Verificar si es par o impar usando el módulo %
            if (numero % 2 == 0) {
                System.out.println("Numero generado: " + numero + " - Es par");
            } else {
                System.out.println("Numero generado: " + numero + " - Es impar");
                
                // Si es impar, lo sumamos al acumulador
                sumaImpares = sumaImpares + numero;
            }
        }

        // Salto de línea
        System.out.println();

        // Resultados al finalizar el bucle
        System.out.println("La suma de los numeros impares es: " + sumaImpares);
        System.out.println("La suma supero el valor 25. El proceso ha finalizado.");
    }
}

