public class Main {
    public static void main(String[] args) {
        // 1. Generar número aleatorio 'm' entre 1 y 20
        int m = (int) (Math.random() * 20) + 1;

        // Mostrar el número generado
        System.out.println("Numero generado: " + m);

        // Variable para ir guardando el acumulado de la suma
        int suma = 0;

        // 2. Estructura repetitiva (bucle for) de 1 a m
        for (int i = 1; i <= m; i++) {
            suma = suma + i; // Le vamos sumando cada número
        }

        // 3. Resultado final
        System.out.println("La suma de los numeros enteros entre 1 y " + m + " es: " + suma);
    }
}
