import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Pedimos la cantidad total de estudiantes
        System.out.print("Ingrese la cantidad total de estudiantes: ");
        int totalEstudiantes = scanner.nextInt();

        System.out.print("Ingrese la cantidad de estudiantes por equipo: ");
        int estudiantesPorEquipo = scanner.nextInt();

        System.out.println();

        // Mostramos los datos ingresados
        System.out.println("Cantidad total de estudiantes: " + totalEstudiantes);
        System.out.println("Estudiantes por equipo: " + estudiantesPorEquipo);

        // Cuentas
        int equiposCompletos = totalEstudiantes / estudiantesPorEquipo;
        int sobrantes = totalEstudiantes % estudiantesPorEquipo;

        // Resultados
        System.out.println("Se pueden formar " + equiposCompletos + " equipos completos.");
        System.out.println("Quedan " + sobrantes + " estudiantes sin integrar un equipo completo.");
        
        scanner.close();
    }
}

