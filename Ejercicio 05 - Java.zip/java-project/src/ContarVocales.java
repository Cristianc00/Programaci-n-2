public class ContarVocales {
    public static void main(String[] args) {
        String texto = "PROGRAMACION JAVA";
        int vocales = 0;

        // Recorre el texto letra por letra
        for (int i = 0; i < texto.length(); i++) {
            char letra = texto.charAt(i);

            // Comprueba si la letra es una vocal
            if (letra == 'A' || letra == 'E' || letra == 'I' || letra == 'O' || letra == 'U') {
                vocales++;
            }
        }

        // Muestra los resultados
        System.out.println("Texto analizado: " + texto);
        System.out.println("Cantidad de caracteres: " + texto.length());
        System.out.println("Cantidad de vocales: " + vocales);
    }
}
