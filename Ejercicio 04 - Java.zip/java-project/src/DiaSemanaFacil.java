import java.util.Random;

public class DiaSemanaFacil {
    public static void main(String[] args) {
        // Genera un número del 1 al 7
        int numero = new Random().nextInt(7) + 1;
        
        System.out.println("Numero generado: " + numero);
        
        // Estructura switch
        String dia = switch (numero) {
            case 1 -> "lunes";
            case 2 -> "martes";
            case 3 -> "miércoles";
            case 4 -> "jueves";
            case 5 -> "viernes";
            case 6 -> "sábado";
            case 7 -> "domingo";
            default -> "";
        };
        
        System.out.println("Dia correspondiente: " + dia);
    }
}
